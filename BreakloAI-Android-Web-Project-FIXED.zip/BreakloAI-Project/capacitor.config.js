import { defineConfig } from '@capacitor/cli';

const config = {
  appId: 'in.sangam.breakloai',
  appName: 'BreakloAI',
  webDir: 'www-build',
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false
  }
};

export default config;
