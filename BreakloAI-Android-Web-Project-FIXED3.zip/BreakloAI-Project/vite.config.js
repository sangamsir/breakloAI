import { defineConfig } from 'vite';
export default defineConfig({
  root: 'www',
  publicDir: '../public',
  build: {
    outDir: '../www-build',
    emptyOutDir: true,
    target: 'es2022',
    rollupOptions: {
      output: {
        entryFileNames: 'assets/[name]-[hash].js',
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash][extname]'
      }
    }
  }
});
