/* Local copies of UI/export libraries: keeps these features available without CDN access. */
import * as katex from 'katex';
import 'katex/dist/katex.min.css';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

window.katex = katex;
window.html2canvas = html2canvas;
window.jspdf = { jsPDF };
