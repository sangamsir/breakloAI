# BreakloAI — Android + Web/PWA source project

This is the prepared Capacitor/Vite project built around the supplied BreakloAI HTML app.

## Included
- `www/index.html`: BreakloAI app and offline-first routing.
- `www/src/vendor.js`: local bundled KaTeX, html2canvas and jsPDF imports (these no longer depend on CDN scripts at runtime).
- `@mlc-ai/web-llm`: bundled JavaScript inference runtime for WebGPU local inference.
- Capacitor 7 Android wrapper configuration (`in.sangam.breakloai`).
- PWA manifest and service worker app-shell caching.
- GitHub Actions workflow to build a debug APK in the cloud.

## Easiest APK build from an Android phone (ZIP upload method)
1. Create a new **public or private GitHub repository**. Do not add a README/license/gitignore when creating it.
2. Upload this ZIP file to the repository root with the exact name `BreakloAI-Android-Web-Project.zip`.
3. In GitHub, create the file `.github/workflows/build-android.yml` and paste the contents of `Build-BreakloAI-from-ZIP.yml` (provided separately with the project download).
4. Open the repository's **Actions** tab, choose **Build BreakloAI Android APK**, and tap **Run workflow**.
5. When the run succeeds, open it and download the `BreakloAI-debug-apk` artifact. Extract it and install `app-debug.apk` on your phone. Allow installation from that source if Android asks.

The ZIP-upload method needs the separate workflow file because GitHub cannot run a workflow that is still trapped inside an uploaded ZIP.

## Build locally (computer with Android SDK)
```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```

## Offline AI: read before testing
- Offline-first is enabled by default. In this mode prompts are not sent to Groq. If the local model is not loaded, the app asks you to download/load it; it does not silently fall back to cloud.
- The WebLLM JavaScript runtime and app dependencies are bundled into the build. Model weights are downloaded once on the device and stored in browser IndexedDB. The first model download needs internet and substantial free storage.
- Local inference requires WebGPU. Support inside Android System WebView depends on Android/WebView version, GPU drivers and available memory. Test on the actual phone; compatibility is not guaranteed.
- This APK is a Capacitor WebView shell using bundled WebLLM. It does **not** contain a separately compiled `llama.cpp` JNI/GGUF native engine. If WebGPU is unavailable in the phone's WebView, offline inference will not work on that phone until a native engine is implemented and tested.
- The service worker caches the app shell and same-origin build assets after first load. Some external integrations and fonts may still need internet.
- Image understanding, image generation and cloud APIs need Online Mode and internet.

## Security
- No shared Groq API key is included. Add your own key in app settings only if you intentionally enable Online Mode.
- If an earlier API key was exposed in a client-side file, revoke it and create a new one. Never commit API keys to GitHub.

## Release status
This is source code plus a debug-APK build workflow, not a signed Play Store release. Before public release, add proper app icons/splash screens, privacy policy, signing key management, permissions review and real-device testing.
