const config = {
  appId: 'in.sangam.breakloai',
  appName: 'BreakloAI',
  webDir: 'www-build',
  android: {
    allowMixedContent: false,
    webContentsDebuggingEnabled: false
  }
};

export default config;
